/**
 * دفتر — جسر المزامنة بين التطبيق وكوكل شيت
 *
 * التركيب:
 *   1. افتح كوكل شيت جديد → Extensions → Apps Script
 *   2. الصق هذا الملف كله بدل المحتوى الموجود
 *   3. غيّر TOKEN تحت لأي كلمة سر تختارها
 *   4. شغّل الدالة setup مرة وحدة (اختر setup من القائمة فوق ودوس Run)
 *   5. Deploy → New deployment → Type: Web app
 *        Execute as: Me
 *        Who has access: Anyone
 *      انسخ الرابط اللي ينتهي بـ /exec وحطه بإعدادات التطبيق مع نفس الرمز
 *
 * ملاحظة مهمة: كل ما تعدّل هذا السكربت، لازم تسوي Deploy → Manage deployments
 * → تعديل النسخة الحالية، وإلا الرابط يبقى يشغّل النسخة القديمة.
 */

var TOKEN = "غيّر-هذا-الرمز";

var P_COLS = ["id","type","name","phone","cur","rate","created","updated","srv"];
var E_COLS = ["id","partyId","date","kind","sign","amount","cur","desc",
              "fxCur","fxAmount","fxRate","rate","voided","reverses","created","updated","srv"];

/* ================= التركيب ================= */

function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var pSh = mkSheet_(ss, "parties", P_COLS);
  var eSh = mkSheet_(ss, "entries", E_COLS);

  // العدّاد لازم يبدي فوق أي علامة موجودة، حتى لو الصفحات فيها بيانات من قبل
  var top = 0;
  [[pSh, P_COLS], [eSh, E_COLS]].forEach(function (pair) {
    var sh = pair[0], cols = pair[1], last = sh.getLastRow();
    if (last < 2) return;
    sh.getRange(2, cols.indexOf("srv") + 1, last - 1, 1).getValues()
      .forEach(function (r) { top = Math.max(top, Number(r[0] || 0)); });
  });
  PropertiesService.getScriptProperties().setProperty("seq", String(top));

  SpreadsheetApp.getUi().alert(
    "تم التركيب. الصفحات جاهزة.\nالخطوة الجاية: Deploy → New deployment → Web app.");
}

function mkSheet_(ss, name, cols) {
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  sh.getRange(1, 1, 1, cols.length).setValues([cols]).setFontWeight("bold");
  sh.setFrozenRows(1);
  // نخلي هذي الأعمدة نص صريح حتى الشيت ما يحولها لتواريخ أو أرقام
  ["id","partyId","date","created"].forEach(function (c) {
    var i = cols.indexOf(c);
    if (i > -1) sh.getRange(2, i + 1, sh.getMaxRows() - 1, 1).setNumberFormat("@");
  });
  return sh;
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("الدفتر")
    .addItem("تحديث صفحة الكشف", "buildReadable")
    .addItem("التركيب من جديد", "setup")
    .addToUi();
}

/* ================= نقطة الدخول ================= */

function doGet() {
  return ContentService
    .createTextOutput(JSON.stringify({ ok: true, msg: "daftar sync endpoint is live" }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var out;
  try {
    if (!e || !e.postData || !e.postData.contents) throw new Error("empty request");
    var body = JSON.parse(e.postData.contents);
    if (String(body.token || "") !== String(TOKEN)) throw new Error("رمز الحماية غير صحيح");

    var lock = LockService.getScriptLock();
    if (!lock.tryLock(25000)) throw new Error("الخادم مشغول، جرّب بعد ثانية");
    try { out = sync_(body); } finally { lock.releaseLock(); }
  } catch (err) {
    out = { ok: false, error: String(err && err.message ? err.message : err) };
  }
  return ContentService
    .createTextOutput(JSON.stringify(out))
    .setMimeType(ContentService.MimeType.JSON);
}

/* ================= المزامنة ================= */

/**
 * srv مو وقت الساعة، هو عدّاد يزيد واحد بكل مزامنة.
 * السبب: لو استخدمنا الساعة وصارت مزامنتين بنفس الجزء من الثانية،
 * الجهاز يحفظ علامة أحدث من سطر موجود فعلاً وما يجيبه أبداً — سطر يضيع بصمت.
 * العدّاد يمنع هذي الحالة نهائياً.
 */
function nextSeq_() {
  var props = PropertiesService.getScriptProperties();
  var n = Number(props.getProperty("seq") || 0) + 1;
  props.setProperty("seq", String(n));
  return n;
}

function sync_(body) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var pSh = ss.getSheetByName("parties") || mkSheet_(ss, "parties", P_COLS);
  var eSh = ss.getSheetByName("entries") || mkSheet_(ss, "entries", E_COLS);

  var seq = nextSeq_();
  var savedP = upsert_(pSh, P_COLS, (body.parties || []).map(flatParty_), seq);
  var savedE = upsert_(eSh, E_COLS, (body.entries || []).map(flatEntry_), seq);

  var since = Number(body.since || 0);
  var skipP = {}; savedP.forEach(function (id) { skipP[id] = 1; });
  var skipE = {}; savedE.forEach(function (id) { skipE[id] = 1; });

  var pulledP = pull_(pSh, P_COLS, since, skipP).map(unflatParty_);
  var pulledE = pull_(eSh, E_COLS, since, skipE).map(unflatEntry_);

  return {
    ok: true,
    now: seq,
    savedParties: savedP,
    savedEntries: savedE,
    parties: pulledP,
    entries: pulledE
  };
}

function upsert_(sh, cols, records, seq) {
  var done = [];
  if (!records.length) return done;

  var last = sh.getLastRow();
  var idRow = {};
  if (last > 1) {
    var ids = sh.getRange(2, 1, last - 1, 1).getValues();
    for (var i = 0; i < ids.length; i++) {
      var v = String(ids[i][0] || "");
      if (v) idRow[v] = i + 2;
    }
  }

  var appends = [];
  for (var r = 0; r < records.length; r++) {
    var rec = records[r];
    if (!rec.id) continue;
    rec.srv = seq;
    var row = cols.map(function (c) { return rec[c] === undefined || rec[c] === null ? "" : rec[c]; });
    var at = idRow[rec.id];
    if (at) sh.getRange(at, 1, 1, cols.length).setValues([row]);
    else appends.push(row);
    done.push(rec.id);
  }
  if (appends.length) {
    sh.getRange(sh.getLastRow() + 1, 1, appends.length, cols.length).setValues(appends);
  }
  return done;
}

function pull_(sh, cols, since, skip) {
  var last = sh.getLastRow();
  if (last < 2) return [];
  var srvAt = cols.indexOf("srv");
  var vals = sh.getRange(2, 1, last - 1, cols.length).getValues();
  var out = [];
  for (var i = 0; i < vals.length; i++) {
    var srv = Number(vals[i][srvAt] || 0);
    if (srv <= since) continue;
    var id = String(vals[i][0] || "");
    if (!id || skip[id]) continue;
    var o = {};
    for (var c = 0; c < cols.length; c++) o[cols[c]] = vals[i][c];
    out.push(o);
  }
  return out;
}

/* ================= تحويل الشكل ================= */

function flatParty_(p) {
  return {
    id: p.id, type: p.type, name: p.name, phone: p.phone || "",
    cur: p.cur || "IQD", rate: Number(p.rate || 0),
    created: p.created || "", updated: Number(p.updated || 0)
  };
}
function unflatParty_(r) {
  return {
    id: String(r.id), type: String(r.type), name: String(r.name),
    phone: String(r.phone || ""), cur: String(r.cur || "IQD"),
    rate: Number(r.rate || 0), created: String(r.created || ""),
    updated: Number(r.updated || 0)
  };
}
function flatEntry_(e) {
  return {
    id: e.id, partyId: e.partyId, date: e.date, kind: e.kind,
    sign: Number(e.sign), amount: Number(e.amount), cur: e.cur || "IQD",
    desc: e.desc || "",
    fxCur: e.fx ? e.fx.cur : "", fxAmount: e.fx ? Number(e.fx.amount) : "",
    fxRate: e.fx ? Number(e.fx.rate) : "",
    rate: e.rate === undefined ? "" : Number(e.rate),
    voided: e.voided ? true : false,
    reverses: e.reverses || "",
    created: e.created || "", updated: Number(e.updated || 0)
  };
}
function unflatEntry_(r) {
  var o = {
    id: String(r.id), partyId: String(r.partyId), date: dstr_(r.date),
    kind: String(r.kind), sign: Number(r.sign), amount: Number(r.amount),
    cur: String(r.cur || "IQD"), desc: String(r.desc || ""),
    voided: r.voided === true || String(r.voided).toUpperCase() === "TRUE",
    created: String(r.created || ""), updated: Number(r.updated || 0)
  };
  if (r.reverses) o.reverses = String(r.reverses);
  if (r.rate !== "" && r.rate !== null && r.rate !== undefined) o.rate = Number(r.rate);
  if (r.fxCur) o.fx = { cur: String(r.fxCur), amount: Number(r.fxAmount), rate: Number(r.fxRate) };
  return o;
}
function dstr_(v) {
  if (v instanceof Date) {
    return v.getFullYear() + "-" +
      ("0" + (v.getMonth() + 1)).slice(-2) + "-" +
      ("0" + v.getDate()).slice(-2);
  }
  return String(v || "");
}

/* ================= صفحة الكشف المقروءة ================= */

function buildReadable() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var pSh = ss.getSheetByName("parties"), eSh = ss.getSheetByName("entries");
  if (!pSh || !eSh) { SpreadsheetApp.getUi().alert("شغّل setup أول."); return; }

  var TYPE = { customer: "زبون", supplier: "مورّد", worker: "موظف" };
  var KIND = { work: "عمل", pay: "تسديد", buy: "شراء", hours: "ساعات", "void": "إلغاء" };

  var pl = pSh.getLastRow(), el = eSh.getLastRow();
  var parties = {}, order = [];
  if (pl > 1) {
    pSh.getRange(2, 1, pl - 1, P_COLS.length).getValues().forEach(function (r) {
      var o = {}; P_COLS.forEach(function (c, i) { o[c] = r[i]; });
      if (!o.id) return;
      parties[String(o.id)] = o; order.push(String(o.id));
    });
  }
  var rows = [];
  if (el > 1) {
    var ev = eSh.getRange(2, 1, el - 1, E_COLS.length).getValues().map(function (r) {
      var o = {}; E_COLS.forEach(function (c, i) { o[c] = r[i]; }); return o;
    });
    order.sort(function (a, b) {
      var A = parties[a], B = parties[b];
      return (A.type + A.name) < (B.type + B.name) ? -1 : 1;
    });
    order.forEach(function (pid) {
      var p = parties[pid];
      var mine = ev.filter(function (x) { return String(x.partyId) === pid; });
      mine.sort(function (a, b) {
        var da = dstr_(a.date), dbb = dstr_(b.date);
        return da === dbb ? (String(a.created) < String(b.created) ? -1 : 1) : (da < dbb ? -1 : 1);
      });
      var run = 0;
      mine.forEach(function (e) {
        run += Number(e.sign) * Number(e.amount);
        var voided = e.voided === true || String(e.voided).toUpperCase() === "TRUE";
        rows.push([
          TYPE[p.type] || p.type,
          p.name,
          dstr_(e.date),
          e.desc,
          KIND[e.kind] || e.kind,
          Number(e.sign) > 0 ? Number(e.amount) : "",
          Number(e.sign) < 0 ? Number(e.amount) : "",
          run,
          p.cur === "USD" ? "دولار" : "دينار",
          e.fxCur ? (e.fxAmount + " " + e.fxCur + " بسعر " + e.fxRate) : "",
          voided ? "ملغي" : ""
        ]);
      });
    });
  }

  var sh = ss.getSheetByName("كشف");
  if (!sh) sh = ss.insertSheet("كشف");
  sh.clear();
  sh.setRightToLeft(true);
  var head = ["النوع", "الاسم", "التاريخ", "البيان", "الحركة", "عليه", "له", "الرصيد", "العملة", "صرف", "حالة"];
  sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight("bold");
  sh.setFrozenRows(1);
  if (rows.length) sh.getRange(2, 1, rows.length, head.length).setValues(rows);
  sh.autoResizeColumns(1, head.length);
  SpreadsheetApp.getUi().alert("تم تحديث صفحة الكشف — " + rows.length + " سطر.");
}
